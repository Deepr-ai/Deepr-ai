from colorama import Fore, Style
import os
print(Fore.CYAN + Style.BRIGHT + "Loaded DeeprAI 0.0.15 BETA" + Fore.RESET + Style.NORMAL)