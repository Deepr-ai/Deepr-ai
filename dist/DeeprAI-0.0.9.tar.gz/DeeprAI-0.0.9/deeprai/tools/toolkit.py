def verify_inputs():
    pass

def fix_inputs():
    pass

def round_out():
    pass
