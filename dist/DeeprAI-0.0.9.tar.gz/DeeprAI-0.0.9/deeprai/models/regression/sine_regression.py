class SineRegression:
    pass