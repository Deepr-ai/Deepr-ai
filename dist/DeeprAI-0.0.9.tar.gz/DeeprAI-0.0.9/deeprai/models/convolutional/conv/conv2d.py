class ForwardValid:
    def __int__(self):
        pass

class ForwardFull:
    def __int__(self):
        pass



