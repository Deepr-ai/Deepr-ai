from colorama import Fore, Style
import os
print(Fore.CYAN + Style.BRIGHT + "Loaded DeeprAI 1.0.2" + Fore.RESET + Style.NORMAL)