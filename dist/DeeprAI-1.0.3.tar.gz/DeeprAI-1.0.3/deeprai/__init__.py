from colorama import Fore, Style
print(Fore.CYAN + Style.BRIGHT + "Loaded DeeprAI 1.0.3" + Fore.RESET + Style.NORMAL)