from colorama import Fore, Style
import os
print(Fore.CYAN + Style.BRIGHT + "Loaded DeeprAI 0.0.14 BETA" + Fore.RESET + Style.NORMAL)