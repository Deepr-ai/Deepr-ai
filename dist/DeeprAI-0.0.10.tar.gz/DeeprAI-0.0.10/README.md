![](images/read_me-header.png)
## What is Deepr-ai?
Deeper-ai is a beginner friendly neural network libary developed in Python and Cython. Deepr-ai is super simple and easy to use. Deepr-ai is made for a level 0 introduction to machine learning to get a understanding of the core consepts and to prepare the user for more advanced frame works (which deepr-ai might make in the future).
## How do you use Deepr-ai?
You can get started and look at examples and by navigating to the "start_up" folder.
## What makes Deepr-ai diffrent from other machine learning libraries?
With Deepr-ai's super easy and simple setup it requires almost no previous knowledge in Python, math, and machine learning to set up a model. However there are more advanced setting for more experanced users.
## Is Deepr-ai finished?
Currently Deepr-ai is under devopment, regular updates are planned granted im in highschool so updates might be delayed. However Deepr-ai still has useful features and practical uses in its unfinished form. 
<p align="center">
Copyright 2023 Kieran Carter
</p>