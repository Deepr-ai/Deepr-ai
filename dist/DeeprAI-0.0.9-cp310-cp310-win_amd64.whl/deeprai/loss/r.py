from deeprai.engine.base_layer import WeightVals

def call():
    print(WeightVals.Weights)
    WeightVals.Weights[1]=9