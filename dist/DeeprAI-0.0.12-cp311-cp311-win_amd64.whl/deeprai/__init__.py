from colorama import Fore, Style
import os

print(Fore.CYAN + Style.BRIGHT + "Loaded DeeprAI 0.0.12 BETA")
print(Fore.RESET + Style.NORMAL)
