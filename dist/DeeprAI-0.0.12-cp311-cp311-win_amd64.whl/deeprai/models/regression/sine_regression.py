class SineRegression:
    def __init__(self):
        print("Feature in development for 0.0.11")